package com.project.dairyproduct.repositories;

import com.project.dairyproduct.models.Feedback;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FeedbackRepository extends JpaRepository<Feedback, Long> {
}

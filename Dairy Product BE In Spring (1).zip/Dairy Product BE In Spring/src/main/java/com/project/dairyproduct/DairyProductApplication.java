package com.project.dairyproduct;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DairyProductApplication {

	public static void main(String[] args) {
		SpringApplication.run(DairyProductApplication.class, args);
	}

}

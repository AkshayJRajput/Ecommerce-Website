module.exports = {
  Parent: "http://localhost:8080/",
};
